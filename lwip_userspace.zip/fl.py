from flask import Flask, request

app = Flask(__name__)

@app.route("/")
def index():
    return f"Flask server reached from {request.remote_addr}\n"

if __name__ == "__main__":
    app.run(
        host="206.77.150.111",
        port=8080,
        debug=False,
        threaded=True
    )
