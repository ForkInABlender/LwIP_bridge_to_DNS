# lwIP DNS53 Magisk deployment

This packages native static lwIP bridges so they can be launched from a privileged Android/Magisk service context.

Included binaries:

- `system/bin/lwip_dns53_bridge` — native UDP socket bridge that binds real port 53.
- `system/bin/lwip_tun_bridge` — TUN/VpnService fd bridge that moves L3 IP packets into lwIP.

Build package from the workspace:

```sh
make -C lwip_userspace magisk-module
```

Output:

```text
lwip_userspace/dist/lwip_dns53_magisk/
lwip_userspace/dist/lwip_dns53_magisk.zip
```

Install the zip with Magisk, reboot, then check the default real-port-53 socket bridge:

```sh
su -c 'cat /data/adb/modules/lwip_dns53/lwip_dns53.log'
dig @127.0.0.1 example.test A
```

Manual TUN bridge test from a privileged shell, if `/dev/net/tun` and `ip` are available:

```sh
su
/data/adb/modules/lwip_dns53/system/bin/lwip_tun_bridge --tun lwip0 &
ip addr add 127.0.0.2/8 dev lwip0
ip link set lwip0 up
dig @127.0.0.1 example.test A
```

Android `VpnService` integration can pass its TUN fd directly:

```sh
lwip_tun_bridge --fd <vpnservice-tun-fd>
```

Default config binds `127.0.0.1:53`. To expose on all interfaces, create/edit:

```sh
su -c 'cat >/data/adb/modules/lwip_dns53/config <<EOF
HOST=0.0.0.0
PORT=53
NAME=example.test
ANSWER=203.0.113.9
EOF'
```

Then reboot or restart the service process.
