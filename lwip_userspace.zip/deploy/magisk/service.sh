#!/system/bin/sh
MODDIR=${0%/*}
BIN="$MODDIR/system/bin/lwip_dns53_bridge"
LOG="$MODDIR/lwip_dns53.log"
CFG="$MODDIR/config"

# Defaults. HOST=127.0.0.1 avoids touching external interfaces.
# Set HOST=0.0.0.0 in $MODDIR/config if you intentionally want LAN/public DNS.
HOST=127.0.0.1
PORT=53
NAME=example.test
ANSWER=203.0.113.9

[ -f "$CFG" ] && . "$CFG"

# Wait for Android userspace/network to settle.
sleep 10

while true; do
  echo "$(date) starting lwIP DNS bridge on ${HOST}:${PORT}; ${NAME} A ${ANSWER}" >> "$LOG"
  "$BIN" --host "$HOST" --port "$PORT" --name "$NAME" --answer "$ANSWER" >> "$LOG" 2>&1
  echo "$(date) lwIP DNS bridge exited with $?; restarting in 5s" >> "$LOG"
  sleep 5
done
