#ifndef LWIP_BOARD_H
#define LWIP_BOARD_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

int lwip_board_init(void);
int lwip_board_input_frame(const uint8_t *frame, size_t len);
int lwip_board_read_frame(uint8_t *out, size_t max_len);
int lwip_board_last_frame_len(void);
void lwip_board_check_timeouts(void);
const char *lwip_board_ip(void);
int lwip_board_selftest(void);
int lwip_board_dns_set_a(const char *name, const char *ipv4);

int lwip_bridge_init(const char *ip, const char *netmask, const char *gateway, uint16_t mtu);
int lwip_bridge_input(const uint8_t *packet, size_t length);
int lwip_bridge_poll_output(uint8_t *buffer, size_t capacity);
int lwip_bridge_poll(uint32_t elapsed_ms);
int lwip_bridge_bind_dns_udp(uint16_t port);
int lwip_bridge_bind_dns_tcp(uint16_t port);
void lwip_bridge_shutdown(void);

#ifdef __cplusplus
}
#endif

#endif
