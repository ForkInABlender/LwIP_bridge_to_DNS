#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/if_tun.h>
#include <net/if.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

#include "lwip_board.h"

static int open_tun_device(const char *path) {
  int fd = open(path, O_RDWR);
  if (fd < 0) {
    fprintf(stderr, "open %s failed: %s\n", path, strerror(errno));
  }
  return fd;
}

static int open_tun(const char *name) {
  int fd = open_tun_device("/dev/tun");
  if (fd < 0) fd = open_tun_device("/dev/net/tun");
  if (fd < 0) return -1;

  struct ifreq ifr;
  memset(&ifr, 0, sizeof(ifr));
  ifr.ifr_flags = IFF_TUN | IFF_NO_PI;
  if (name && *name) {
    snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", name);
  }

  if (ioctl(fd, TUNSETIFF, (void *)&ifr) < 0) {
    perror("ioctl TUNSETIFF");
    close(fd);
    return -1;
  }

  fprintf(stderr, "opened TUN interface %s\n", ifr.ifr_name);
  return fd;
}

static void usage(const char *argv0) {
  fprintf(stderr,
          "Usage: %s (--fd N | --stdio | --tun lwip0) [--name example.test] [--answer 203.0.113.9]\n"
          "\n"
          "Bridges L3 TUN/VpnService raw IPv4 packets directly into lwIP.\n"
          "Preferred Android path: pass a VpnService ParcelFileDescriptor with --fd N.\n"
          "No native /dev/tun access is needed when --fd or --stdio is used.\n"
          "Expected peer config for Linux TUN testing, if permissions allow:\n"
          "  ip addr add 127.0.0.2/8 dev lwip0\n"
          "  ip link set lwip0 up\n"
          "  dig @127.0.0.1 example.test A\n",
          argv0);
}

int main(int argc, char **argv) {
  const char *tun_name = NULL;
  int read_fd = -1;
  int write_fd = -1;
  int eof_exits = 0;
  const char *name = "example.test";
  const char *answer = "203.0.113.9";

  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--tun") && i + 1 < argc) tun_name = argv[++i];
    else if (!strcmp(argv[i], "--fd") && i + 1 < argc) {
      read_fd = atoi(argv[++i]);
      write_fd = read_fd;
    }
    else if (!strcmp(argv[i], "--stdio")) {
      read_fd = STDIN_FILENO;
      write_fd = STDOUT_FILENO;
      eof_exits = 1;
    }
    else if (!strcmp(argv[i], "--name") && i + 1 < argc) name = argv[++i];
    else if (!strcmp(argv[i], "--answer") && i + 1 < argc) answer = argv[++i];
    else if (!strcmp(argv[i], "--help")) { usage(argv[0]); return 0; }
    else { usage(argv[0]); return 2; }
  }

  if (lwip_board_init() != 0) {
    fprintf(stderr, "lwip_board_init failed\n");
    return 1;
  }
  if (lwip_board_dns_set_a(name, answer) != 0) {
    fprintf(stderr, "invalid DNS record: %s A %s\n", name, answer);
    return 1;
  }

  if (read_fd < 0 && tun_name) {
    read_fd = open_tun(tun_name);
    write_fd = read_fd;
    if (read_fd < 0) return 1;
  }

  if (read_fd < 0 || write_fd < 0) {
    fprintf(stderr, "no packet source selected; use --fd N, --stdio, or --tun NAME\n");
    usage(argv[0]);
    return 2;
  }

  fprintf(stderr, "lwIP TUN bridge running; lwIP IP=%s DNS %s A %s\n", lwip_board_ip(), name, answer);

  for (;;) {
    uint8_t ip[1600];
    uint8_t reply[1700];

    ssize_t n = read(read_fd, ip, sizeof(ip));
    if (n < 0) {
      if (errno == EINTR) continue;
      perror("read tun");
      break;
    }
    if (n == 0) {
      if (eof_exits) break;
      continue;
    }

    if (lwip_board_input_frame(ip, (size_t)n) != 0) continue;
    lwip_board_check_timeouts();

    int reply_len = lwip_board_read_frame(reply, sizeof(reply));
    if (reply_len <= 0) continue;

    ssize_t wrote = write(write_fd, reply, (size_t)reply_len);
    if (wrote < 0) perror("write tun");
  }

  if (read_fd >= 0 && !eof_exits) close(read_fd);
  return 1;
}
