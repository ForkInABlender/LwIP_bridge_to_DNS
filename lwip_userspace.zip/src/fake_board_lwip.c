#include <stdio.h>
#include "lwip_board.h"

int main(void) {
  if (lwip_board_init() != 0) {
    fprintf(stderr, "lwip_board_init failed\n");
    return 1;
  }

  printf("lwIP userspace fake board up: e0 ip=%s\n", lwip_board_ip());

  int rc = lwip_board_selftest();
  if (rc != 0) {
    fprintf(stderr, "selftest failed: %d\n", rc);
    return rc;
  }

  printf("TX frame: %d bytes\n", lwip_board_last_frame_len());
  printf("PASS: lwIP accepted Ethernet/IP/ICMP input and emitted a valid echo reply entirely in userspace.\n");
  return 0;
}
