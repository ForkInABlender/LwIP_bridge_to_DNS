#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#include "lwip_board.h"

static const uint8_t HOST_MAC[6] = {0x02,0x00,0x00,0x00,0x00,0x99};
static const uint8_t BOARD_MAC[6] = {0x02,0x00,0x00,0x00,0x00,0x42};
static const uint8_t HOST_IP[4] = {192,168,7,1};
static const uint8_t BOARD_IP[4] = {192,168,7,42};
static volatile sig_atomic_t running = 1;

static void on_signal(int sig) {
  (void)sig;
  running = 0;
}

static uint16_t checksum16(const uint8_t *data, size_t len) {
  uint32_t sum = 0;
  while (len > 1) {
    sum += (uint16_t)(((uint16_t)data[0] << 8) | data[1]);
    data += 2;
    len -= 2;
  }
  if (len) sum += (uint16_t)((uint16_t)data[0] << 8);
  while (sum >> 16) sum = (sum & 0xffffu) + (sum >> 16);
  return (uint16_t)~sum;
}

static void put_be16(uint8_t *p, uint16_t v) {
  p[0] = (uint8_t)(v >> 8);
  p[1] = (uint8_t)(v & 0xffu);
}

static int build_lwip_udp53_frame(uint8_t *packet, size_t packet_cap, const uint8_t *dns, size_t dns_len, uint16_t client_port) {
  size_t udp_len = 8 + dns_len;
  size_t ip_len = 20 + udp_len;
  size_t total = 14 + ip_len;
  if (dns_len > 512 || packet_cap < total) return -1;

  memset(packet, 0, total);
  memcpy(packet + 0, BOARD_MAC, 6);
  memcpy(packet + 6, HOST_MAC, 6);
  packet[12] = 0x08;
  packet[13] = 0x00;
  uint8_t *ip = packet + 14;
  ip[0] = 0x45;
  ip[1] = 0x00;
  put_be16(ip + 2, (uint16_t)ip_len);
  put_be16(ip + 4, 0xabcd);
  put_be16(ip + 6, 0x0000);
  ip[8] = 64;
  ip[9] = 17; /* UDP */
  memcpy(ip + 12, HOST_IP, 4);
  memcpy(ip + 16, BOARD_IP, 4);
  put_be16(ip + 10, checksum16(ip, 20));

  uint8_t *udp = ip + 20;
  put_be16(udp + 0, client_port);
  put_be16(udp + 2, 53);
  put_be16(udp + 4, (uint16_t)udp_len);
  put_be16(udp + 6, 0); /* lwIP accepts zero IPv4 UDP checksum */
  memcpy(udp + 8, dns, dns_len);
  return (int)total;
}

static int extract_dns_payload(const uint8_t *frame, size_t frame_len, const uint8_t **payload, size_t *payload_len) {
  if (frame_len < 14 + 20 + 8) return -1;
  if (frame[12] != 0x08 || frame[13] != 0x00) return -2;
  const uint8_t *ip = frame + 14;
  size_t ihl = (size_t)(ip[0] & 0x0fu) * 4u;
  if (ihl < 20 || frame_len < 14 + ihl + 8) return -3;
  if (ip[9] != 17) return -4;
  const uint8_t *udp = ip + ihl;
  uint16_t udp_len = (uint16_t)(((uint16_t)udp[4] << 8) | udp[5]);
  if (udp_len < 8 || frame_len < 14 + ihl + udp_len) return -5;
  *payload = udp + 8;
  *payload_len = udp_len - 8u;
  return 0;
}

static void usage(const char *argv0) {
  fprintf(stderr,
          "Usage: %s [--host 127.0.0.1] [--port 53] [--name example.test] [--answer 203.0.113.9]\n"
          "\n"
          "Native lwIP DNS bridge. Defaults to real DNS port 53.\n",
          argv0);
}

int main(int argc, char **argv) {
  const char *host = "127.0.0.1";
  int port = 53;
  const char *name = "example.test";
  const char *answer = "203.0.113.9";

  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--host") && i + 1 < argc) host = argv[++i];
    else if (!strcmp(argv[i], "--port") && i + 1 < argc) port = atoi(argv[++i]);
    else if (!strcmp(argv[i], "--name") && i + 1 < argc) name = argv[++i];
    else if (!strcmp(argv[i], "--answer") && i + 1 < argc) answer = argv[++i];
    else if (!strcmp(argv[i], "--help")) { usage(argv[0]); return 0; }
    else { usage(argv[0]); return 2; }
  }

  if (port <= 0 || port > 65535) {
    fprintf(stderr, "invalid port: %d\n", port);
    return 2;
  }

  if (lwip_board_init() != 0) {
    fprintf(stderr, "lwip_board_init failed\n");
    return 1;
  }
  if (lwip_board_dns_set_a(name, answer) != 0) {
    fprintf(stderr, "invalid DNS record: %s A %s\n", name, answer);
    return 1;
  }

  int fd = socket(AF_INET, SOCK_DGRAM, 0);
  if (fd < 0) {
    perror("socket");
    return 1;
  }

  int one = 1;
  setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));

  struct sockaddr_in bind_addr;
  memset(&bind_addr, 0, sizeof(bind_addr));
  bind_addr.sin_family = AF_INET;
  bind_addr.sin_port = htons((uint16_t)port);
  if (inet_pton(AF_INET, host, &bind_addr.sin_addr) != 1) {
    fprintf(stderr, "invalid IPv4 bind host: %s\n", host);
    close(fd);
    return 2;
  }

  if (bind(fd, (struct sockaddr *)&bind_addr, sizeof(bind_addr)) != 0) {
    fprintf(stderr, "bind %s:%d failed: %s\n", host, port, strerror(errno));
    close(fd);
    return 1;
  }

  signal(SIGINT, on_signal);
  signal(SIGTERM, on_signal);
  printf("native lwIP DNS bridge listening on %s:%d; %s A %s\n", host, port, name, answer);
  fflush(stdout);

  while (running) {
    uint8_t dns[512];
    uint8_t packet[1600];
    uint8_t reply_packet[1600];
    struct sockaddr_in client;
    socklen_t client_len = sizeof(client);
    ssize_t n = recvfrom(fd, dns, sizeof(dns), 0, (struct sockaddr *)&client, &client_len);
    if (n < 0) {
      if (errno == EINTR) continue;
      perror("recvfrom");
      continue;
    }

    int packet_len = build_lwip_udp53_frame(packet, sizeof(packet), dns, (size_t)n, ntohs(client.sin_port));
    if (packet_len <= 0 || lwip_board_input_frame(packet, (size_t)packet_len) != 0) continue;
    lwip_board_check_timeouts();

    int reply_len = lwip_board_read_frame(reply_packet, sizeof(reply_packet));
    if (reply_len <= 0) continue;

    const uint8_t *payload = NULL;
    size_t payload_len = 0;
    if (extract_dns_payload(reply_packet, (size_t)reply_len, &payload, &payload_len) != 0) continue;
    sendto(fd, payload, payload_len, 0, (struct sockaddr *)&client, client_len);
  }

  close(fd);
  return 0;
}
