#include "lwip_board.h"

#include <stdint.h>
#include <string.h>
#include <time.h>

#include "lwip/init.h"
#include "lwip/netif.h"
#include "lwip/timeouts.h"
#include "lwip/ip4_addr.h"
#include "lwip/pbuf.h"
#include "lwip/etharp.h"
#include "lwip/udp.h"
#include "lwip/prot/ethernet.h"
#include "lwip/prot/ip4.h"
#include "lwip/prot/ip.h"
#include "lwip/prot/icmp.h"
#include "lwip/inet_chksum.h"
#include "netif/ethernet.h"

static struct netif board_netif;
static int initialized;
static uint8_t last_tx[1600];
static u16_t last_tx_len;
static struct udp_pcb *dns_pcb;
static char dns_name[256] = "example.test";
static ip4_addr_t dns_a;
static const uint8_t host_mac[6] = {0x02,0x00,0x00,0x00,0x00,0x99};
static const uint8_t board_mac[6] = {0x02,0x00,0x00,0x00,0x00,0x42};

static uint16_t get_be16(const uint8_t *p) {
  return (uint16_t)(((uint16_t)p[0] << 8) | p[1]);
}

static void put_be16(uint8_t *p, uint16_t v) {
  p[0] = (uint8_t)(v >> 8);
  p[1] = (uint8_t)(v & 0xffu);
}

static void put_be32(uint8_t *p, uint32_t v) {
  p[0] = (uint8_t)(v >> 24);
  p[1] = (uint8_t)((v >> 16) & 0xffu);
  p[2] = (uint8_t)((v >> 8) & 0xffu);
  p[3] = (uint8_t)(v & 0xffu);
}

static int ascii_lower(int ch) {
  return (ch >= 'A' && ch <= 'Z') ? ch + ('a' - 'A') : ch;
}

static int dns_name_equal(const char *a, const char *b) {
  while (*a && *b) {
    if (ascii_lower((unsigned char)*a) != ascii_lower((unsigned char)*b)) return 0;
    a++;
    b++;
  }
  return *a == '\0' && *b == '\0';
}

static int parse_dns_qname(const uint8_t *msg, size_t len, size_t off, char *out, size_t out_len, size_t *end_off) {
  size_t pos = 0;
  if (off >= len || out_len == 0) return -1;

  while (off < len) {
    uint8_t labellen = msg[off++];
    if (labellen == 0) {
      if (pos == 0) {
        if (pos + 1 >= out_len) return -1;
        out[pos++] = '.';
      }
      out[pos] = '\0';
      *end_off = off;
      return 0;
    }
    if ((labellen & 0xc0u) != 0 || labellen > 63 || off + labellen > len) return -1;
    if (pos != 0) {
      if (pos + 1 >= out_len) return -1;
      out[pos++] = '.';
    }
    if (pos + labellen >= out_len) return -1;
    memcpy(out + pos, msg + off, labellen);
    pos += labellen;
    off += labellen;
  }
  return -1;
}

static void dns_recv(void *arg, struct udp_pcb *pcb, struct pbuf *p, const ip_addr_t *addr, u16_t port) {
  (void)arg;
  uint8_t query[512];
  uint8_t response[512];
  char qname[256];
  size_t qend;
  uint16_t qtype, qclass;
  size_t qlen;
  int match;

  if (!p) return;
  if (p->tot_len > sizeof(query) || p->tot_len < 12) {
    pbuf_free(p);
    return;
  }
  qlen = p->tot_len;
  pbuf_copy_partial(p, query, p->tot_len, 0);
  pbuf_free(p);

  if (get_be16(query + 4) != 1 || parse_dns_qname(query, qlen, 12, qname, sizeof(qname), &qend) != 0) return;
  if (qend + 4 > qlen) return;
  qtype = get_be16(query + qend);
  qclass = get_be16(query + qend + 2);
  match = (qtype == 1 && qclass == 1 && dns_name_equal(qname, dns_name));

  memcpy(response, query, qend + 4);
  put_be16(response + 2, (uint16_t)(dns_name_equal(qname, dns_name) ? 0x8180 : 0x8183));
  put_be16(response + 6, (uint16_t)(match ? 1 : 0));
  put_be16(response + 8, 0);
  put_be16(response + 10, 0);

  size_t rlen = qend + 4;
  if (match) {
    if (rlen + 16 > sizeof(response)) return;
    response[rlen++] = 0xc0;
    response[rlen++] = 0x0c;
    put_be16(response + rlen, 1); rlen += 2;      /* A */
    put_be16(response + rlen, 1); rlen += 2;      /* IN */
    put_be32(response + rlen, 60); rlen += 4;     /* TTL */
    put_be16(response + rlen, 4); rlen += 2;
    memcpy(response + rlen, &dns_a.addr, 4); rlen += 4;
  }

  struct pbuf *rp = pbuf_alloc(PBUF_TRANSPORT, (u16_t)rlen, PBUF_RAM);
  if (!rp) return;
  pbuf_take(rp, response, (u16_t)rlen);
  udp_sendto(pcb, rp, addr, port);
  pbuf_free(rp);
}

static int dns_start(void) {
  IP4_ADDR(&dns_a, 203,0,113,42);
  dns_pcb = udp_new();
  if (!dns_pcb) return -1;
  if (udp_bind(dns_pcb, IP_ADDR_ANY, 53) != ERR_OK) return -2;
  udp_recv(dns_pcb, dns_recv, NULL);
  return 0;
}

u32_t sys_now(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u32_t)(ts.tv_sec * 1000u + ts.tv_nsec / 1000000u);
}

static err_t board_linkoutput(struct netif *netif, struct pbuf *p) {
  (void)netif;
  if (p->tot_len > sizeof(last_tx)) return ERR_BUF;
  pbuf_copy_partial(p, last_tx, p->tot_len, 0);
  last_tx_len = p->tot_len;
  return ERR_OK;
}

static err_t board_netif_init(struct netif *netif) {
  netif->name[0] = 'e';
  netif->name[1] = '0';
  netif->hwaddr_len = ETH_HWADDR_LEN;
  memcpy(netif->hwaddr, board_mac, 6);
  netif->mtu = 1500;
  netif->flags = NETIF_FLAG_BROADCAST | NETIF_FLAG_ETHARP | NETIF_FLAG_ETHERNET | NETIF_FLAG_LINK_UP;
  netif->output = etharp_output;
  netif->linkoutput = board_linkoutput;
  return ERR_OK;
}

int lwip_board_init(void) {
  if (initialized) return 0;

  lwip_init();

  ip4_addr_t ipaddr, netmask, gw;
  IP4_ADDR(&ipaddr, 127,0,0,1);
  IP4_ADDR(&netmask, 255,0,0,0);
  IP4_ADDR(&gw, 127,0,0,1);

  if (!netif_add(&board_netif, &ipaddr, &netmask, &gw, NULL, board_netif_init, ethernet_input)) {
    return -1;
  }
  netif_set_default(&board_netif);
  netif_set_up(&board_netif);
  netif_set_link_up(&board_netif);

  ip4_addr_t host_ip;
  struct eth_addr host_eth;
  IP4_ADDR(&host_ip, 127,0,0,2);
  memcpy(&host_eth, host_mac, 6);
  etharp_add_static_entry(&host_ip, &host_eth);

  if (dns_start() != 0) return -2;

  initialized = 1;
  return 0;
}

int lwip_board_dns_set_a(const char *name, const char *ipv4) {
  ip4_addr_t parsed;
  size_t len;
  if (!name || !ipv4) return -1;
  len = strlen(name);
  if (len == 0 || len >= sizeof(dns_name)) return -2;
  if (!ip4addr_aton(ipv4, &parsed)) return -3;
  memcpy(dns_name, name, len + 1);
  dns_a = parsed;
  return 0;
}

int lwip_board_input_frame(const uint8_t *frame, size_t len) {
  if (!initialized && lwip_board_init() != 0) return -1;
  if (!frame || len == 0 || len > 1600) return -2;

  struct pbuf *p = pbuf_alloc(PBUF_RAW, (u16_t)len, PBUF_POOL);
  if (!p) return -3;
  pbuf_take(p, frame, (u16_t)len);
  err_t e = ethernet_input(p, &board_netif);
  if (e != ERR_OK) {
    pbuf_free(p);
    return (int)e;
  }
  return 0;
}

int lwip_board_read_frame(uint8_t *out, size_t max_len) {
  if (!out) return -1;
  if (last_tx_len == 0) return 0;
  if (max_len < last_tx_len) return -2;
  u16_t copied = last_tx_len;
  memcpy(out, last_tx, copied);
  last_tx_len = 0;
  return (int)copied;
}

int lwip_board_last_frame_len(void) {
  return (int)last_tx_len;
}

void lwip_board_check_timeouts(void) {
  if (!initialized) return;
  sys_check_timeouts();
}

const char *lwip_board_ip(void) {
  if (!initialized && lwip_board_init() != 0) return "0.0.0.0";
  return ip4addr_ntoa(netif_ip4_addr(&board_netif));
}

static int make_icmp_echo_request(uint8_t *frame, size_t max_len) {
  const size_t len = 14 + 20 + 8 + 8;
  if (max_len < len) return -1;
  memset(frame, 0, len);

  struct eth_hdr *eth = (struct eth_hdr *)frame;
  memcpy(&eth->dest, board_mac, 6);
  memcpy(&eth->src, host_mac, 6);
  eth->type = PP_HTONS(ETHTYPE_IP);

  struct ip_hdr *ip = (struct ip_hdr *)(frame + SIZEOF_ETH_HDR);
  IPH_VHL_SET(ip, 4, 5);
  IPH_TOS_SET(ip, 0);
  IPH_LEN_SET(ip, PP_HTONS(20 + 8 + 8));
  IPH_ID_SET(ip, PP_HTONS(0x1234));
  IPH_OFFSET_SET(ip, 0);
  IPH_TTL_SET(ip, 64);
  IPH_PROTO_SET(ip, IP_PROTO_ICMP);
  ip4_addr_t src, dst;
  IP4_ADDR(&src, 127,0,0,2);
  IP4_ADDR(&dst, 127,0,0,1);
  ip->src.addr = src.addr;
  ip->dest.addr = dst.addr;
  IPH_CHKSUM_SET(ip, 0);
  IPH_CHKSUM_SET(ip, inet_chksum(ip, 20));

  struct icmp_echo_hdr *icmp = (struct icmp_echo_hdr *)(frame + SIZEOF_ETH_HDR + 20);
  ICMPH_TYPE_SET(icmp, ICMP_ECHO);
  ICMPH_CODE_SET(icmp, 0);
  icmp->id = PP_HTONS(0xbeef);
  icmp->seqno = PP_HTONS(1);
  memcpy((uint8_t*)icmp + 8, "lwiptest", 8);
  icmp->chksum = 0;
  icmp->chksum = inet_chksum(icmp, 16);
  return (int)len;
}

static int validate_echo_reply(void) {
  if (last_tx_len < 14 + 20 + 8) return 0;
  const struct eth_hdr *eth = (const struct eth_hdr *)last_tx;
  if (memcmp(&eth->dest, host_mac, 6) != 0) return 0;
  if (memcmp(&eth->src, board_mac, 6) != 0) return 0;
  if (PP_NTOHS(eth->type) != ETHTYPE_IP) return 0;
  const struct ip_hdr *ip = (const struct ip_hdr *)(last_tx + SIZEOF_ETH_HDR);
  if (IPH_PROTO(ip) != IP_PROTO_ICMP) return 0;
  const struct icmp_echo_hdr *icmp = (const struct icmp_echo_hdr *)(last_tx + SIZEOF_ETH_HDR + 20);
  return ICMPH_TYPE(icmp) == ICMP_ER && PP_NTOHS(icmp->id) == 0xbeef && PP_NTOHS(icmp->seqno) == 1;
}

int lwip_board_selftest(void) {
  uint8_t frame[64];
  int len;

  if (lwip_board_init() != 0) return 1;
  len = make_icmp_echo_request(frame, sizeof(frame));
  if (len <= 0) return 2;
  last_tx_len = 0;
  if (lwip_board_input_frame(frame, (size_t)len) != 0) return 3;
  lwip_board_check_timeouts();
  return validate_echo_reply() ? 0 : 4;
}

int lwip_bridge_init(const char *ip, const char *netmask, const char *gateway, uint16_t mtu) {
  (void)ip;
  (void)netmask;
  (void)gateway;
  (void)mtu;
  return lwip_board_init();
}

int lwip_bridge_input(const uint8_t *packet, size_t length) {
  return lwip_board_input_frame(packet, length);
}

int lwip_bridge_poll_output(uint8_t *buffer, size_t capacity) {
  return lwip_board_read_frame(buffer, capacity);
}

int lwip_bridge_poll(uint32_t elapsed_ms) {
  (void)elapsed_ms;
  lwip_board_check_timeouts();
  return 0;
}

int lwip_bridge_bind_dns_udp(uint16_t port) {
  return port == 53 ? 0 : -1;
}

int lwip_bridge_bind_dns_tcp(uint16_t port) {
  (void)port;
  return -1;
}

void lwip_bridge_shutdown(void) {
  initialized = 0;
}
