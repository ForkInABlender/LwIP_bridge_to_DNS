from lwip_board import LwipBoard

board = LwipBoard()
board.init()
print(f"lwIP board IP: {board.ip}")
board.selftest()
reply = board.read_frame()
print(f"Python received TX frame from lwIP: {len(reply)} bytes")
print("PASS: normal Python code used lwIP through ctypes")
