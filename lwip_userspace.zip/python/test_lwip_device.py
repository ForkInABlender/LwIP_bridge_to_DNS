from __future__ import annotations

import threading
import time

from python_device import DeviceConfiguration, PythonPacketDevice, validate_ipv4_packet
from python_lwip_client import CLIENT_IP, SERVER_IP, dns_udp_query_packet, parse_udp_dns_response
from python_lwip_server import PythonLwipServer


def expect_raises(fn, message: str) -> None:
    try:
        fn()
    except ValueError as exc:
        assert message in str(exc), str(exc)
        return
    raise AssertionError(f"expected ValueError containing {message!r}")


def test_device_queues_and_stats() -> None:
    dev = PythonPacketDevice(DeviceConfiguration())
    pkt = dns_udp_query_packet("example.test")
    dev.inject_packet(pkt)
    assert dev.receive_packet(timeout=0.01) == pkt
    dev.transmit_packet(pkt)
    assert dev.next_transmitted_packet(timeout=0.01) == pkt
    stats = dev.get_stats()
    assert stats["rx_packet_count"] == 1
    assert stats["tx_packet_count"] == 1
    assert stats["rx_byte_count"] == len(pkt)
    assert stats["tx_byte_count"] == len(pkt)


def test_oversized_packets_are_rejected() -> None:
    dev = PythonPacketDevice(DeviceConfiguration(mtu=32))
    expect_raises(lambda: dev.inject_packet(dns_udp_query_packet("example.test")), "Packet exceeds MTU")


def test_malformed_ipv4_rejected() -> None:
    expect_raises(lambda: validate_ipv4_packet(b"\x45"), "IPv4 packet too short")
    expect_raises(lambda: validate_ipv4_packet(b"\x60" + b"\x00" * 39), "Not IPv4")


def test_raw_ipv4_udp_dns_through_lwip() -> None:
    dev = PythonPacketDevice(DeviceConfiguration())
    server = PythonLwipServer(device=dev)
    thread = threading.Thread(target=server.network_loop, daemon=True)
    thread.start()
    try:
        pkt = dns_udp_query_packet("example.test", source_port=53000, txid=b"\xca\xfe")
        dev.inject_packet(pkt)
        deadline = time.time() + 2.0
        reply = None
        while time.time() < deadline:
            reply = dev.next_transmitted_packet(timeout=0.05)
            if reply:
                break
        assert reply is not None
        parsed = parse_udp_dns_response(reply)
        assert parsed["src_ip"] == SERVER_IP
        assert parsed["dst_ip"] == CLIENT_IP
        assert parsed["src_port"] == 53
        assert parsed["dst_port"] == 53000
        dns = parsed["dns"]
        assert dns[0:2] == b"\xca\xfe"
        assert dns[2:4] == b"\x81\x80"
        assert dns[6:8] == b"\x00\x01"
        assert dns[-4:] == bytes([203, 0, 113, 42])
        stats = dev.get_stats()
        assert stats["dns_udp_query_count"] == 1
        assert stats["dns_response_count"] == 1
    finally:
        server.stop()
        thread.join(timeout=1.0)


def main() -> None:
    tests = [
        test_device_queues_and_stats,
        test_oversized_packets_are_rejected,
        test_malformed_ipv4_rejected,
        test_raw_ipv4_udp_dns_through_lwip,
    ]
    for test in tests:
        test()
        print(f"PASS: {test.__name__}")


if __name__ == "__main__":
    main()
