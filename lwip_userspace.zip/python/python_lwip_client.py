from __future__ import annotations

CLIENT_IP = bytes([127, 0, 0, 2])
SERVER_IP = bytes([127, 0, 0, 1])


def checksum(data: bytes) -> int:
    if len(data) & 1:
        data += b"\x00"
    total = 0
    for i in range(0, len(data), 2):
        total += (data[i] << 8) + data[i + 1]
    while total >> 16:
        total = (total & 0xFFFF) + (total >> 16)
    return (~total) & 0xFFFF


def qname(name: str) -> bytes:
    out = bytearray()
    for label in name.rstrip(".").split("."):
        raw = label.encode("ascii")
        out.append(len(raw))
        out.extend(raw)
    out.append(0)
    return bytes(out)


def udp_checksum(src_ip: bytes, dst_ip: bytes, udp: bytes) -> int:
    pseudo = src_ip + dst_ip + b"\x00\x11" + len(udp).to_bytes(2, "big")
    return checksum(pseudo + udp)


def dns_udp_query_packet(name: str, source_port: int = 53000, txid: bytes = b"\x12\x34") -> bytes:
    dns = (
        txid
        + b"\x01\x00"
        + b"\x00\x01"
        + b"\x00\x00"
        + b"\x00\x00"
        + b"\x00\x00"
        + qname(name)
        + b"\x00\x01"
        + b"\x00\x01"
    )
    udp_len = 8 + len(dns)
    udp = bytearray(source_port.to_bytes(2, "big") + (53).to_bytes(2, "big") + udp_len.to_bytes(2, "big") + b"\x00\x00" + dns)
    # IPv4 permits zero UDP checksum, but produce a real one for tests.
    csum = udp_checksum(CLIENT_IP, SERVER_IP, bytes(udp))
    udp[6:8] = csum.to_bytes(2, "big")
    ip_len = 20 + len(udp)
    ip = bytearray(b"\x45\x00" + ip_len.to_bytes(2, "big") + b"\xab\xcd\x00\x00\x40\x11\x00\x00" + CLIENT_IP + SERVER_IP)
    ip[10:12] = checksum(ip).to_bytes(2, "big")
    return bytes(ip) + bytes(udp)


def parse_udp_dns_response(packet: bytes) -> dict[str, object]:
    ihl = (packet[0] & 0x0F) * 4
    udp = packet[ihl:]
    payload = udp[8:]
    return {
        "src_ip": packet[12:16],
        "dst_ip": packet[16:20],
        "src_port": int.from_bytes(udp[0:2], "big"),
        "dst_port": int.from_bytes(udp[2:4], "big"),
        "udp_checksum": int.from_bytes(udp[6:8], "big"),
        "dns": payload,
    }
