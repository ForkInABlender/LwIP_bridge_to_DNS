from __future__ import annotations

import threading
import time

from lwip_board import LwipBoard
from python_device import DeviceConfiguration, PythonPacketDevice


class PythonLwipServer:
    def __init__(self, device: PythonPacketDevice | None = None, lwip: LwipBoard | None = None) -> None:
        self.device = device or PythonPacketDevice(DeviceConfiguration())
        self.lwip = lwip or LwipBoard()
        self.shutdown_event = threading.Event()

    def start(self) -> None:
        self.lwip.init()

    def stop(self) -> None:
        self.shutdown_event.set()

    def network_loop(self) -> None:
        self.start()
        last_time = time.monotonic()
        while not self.shutdown_event.is_set():
            now = time.monotonic()
            elapsed_ms = int((now - last_time) * 1000)
            if elapsed_ms > 0:
                self.lwip.poll(elapsed_ms)
                last_time = now

            packet = self.device.receive_packet(timeout=0.01)
            if packet is not None:
                self.lwip.input_packet(packet)
                self.device.dns_udp_query_count += _is_udp_dns_query(packet)

            while True:
                outgoing = self.lwip.poll_output()
                if not outgoing:
                    break
                self.device.transmit_packet(outgoing)
                self.device.dns_response_count += _is_udp_dns_response(outgoing)


def _is_udp_dns_query(packet: bytes) -> int:
    try:
        ihl = (packet[0] & 0x0F) * 4
        return int(packet[9] == 17 and int.from_bytes(packet[ihl + 2:ihl + 4], "big") == 53)
    except Exception:
        return 0


def _is_udp_dns_response(packet: bytes) -> int:
    try:
        ihl = (packet[0] & 0x0F) * 4
        return int(packet[9] == 17 and int.from_bytes(packet[ihl:ihl + 2], "big") == 53)
    except Exception:
        return 0
