from lwip_board import LwipBoard

HOST_MAC = bytes.fromhex("020000000099")
BOARD_MAC = bytes.fromhex("020000000042")
HOST_IP = bytes([192, 168, 7, 1])
BOARD_IP = bytes([192, 168, 7, 42])


def checksum(data: bytes) -> int:
    if len(data) & 1:
        data += b"\x00"
    total = 0
    for i in range(0, len(data), 2):
        total += (data[i] << 8) + data[i + 1]
    while total >> 16:
        total = (total & 0xFFFF) + (total >> 16)
    return (~total) & 0xFFFF


def qname(name: str) -> bytes:
    out = bytearray()
    for label in name.rstrip(".").split("."):
        raw = label.encode("ascii")
        out.append(len(raw))
        out.extend(raw)
    out.append(0)
    return bytes(out)


def dns_query_frame(name: str) -> bytes:
    dns = (
        b"\x12\x34"
        b"\x01\x00"
        b"\x00\x01"
        b"\x00\x00"
        b"\x00\x00"
        b"\x00\x00"
        + qname(name)
        + b"\x00\x01"
        + b"\x00\x01"
    )
    udp_len = 8 + len(dns)
    udp = (53000).to_bytes(2, "big") + (53).to_bytes(2, "big") + udp_len.to_bytes(2, "big") + b"\x00\x00" + dns
    ip_len = 20 + len(udp)
    ip = bytearray(b"\x45\x00" + ip_len.to_bytes(2, "big") + b"\xab\xcd\x00\x00\x40\x11\x00\x00" + HOST_IP + BOARD_IP)
    ip[10:12] = checksum(ip).to_bytes(2, "big")
    return BOARD_MAC + HOST_MAC + b"\x08\x00" + bytes(ip) + udp


def udp_payload(frame: bytes) -> bytes:
    ip_start = 14
    ihl = (frame[ip_start] & 0x0F) * 4
    udp_start = ip_start + ihl
    return frame[udp_start + 8:]


board = LwipBoard()
board.init()
assert board.ip == "192.168.7.42"
board.dns_set_a("example.test", "203.0.113.9")
board.input_frame(dns_query_frame("example.test"))
reply = board.read_frame()
assert reply[0:6] == HOST_MAC, reply.hex()
assert reply[6:12] == BOARD_MAC, reply.hex()
payload = udp_payload(reply)
assert payload[0:2] == b"\x12\x34"
assert payload[6:8] == b"\x00\x01", payload.hex()
assert payload[-4:] == bytes([203, 0, 113, 9]), payload.hex()
print(f"PASS: Ethernet-framed lwIP DNS responder returned example.test A {'.'.join(map(str, payload[-4:]))}")
