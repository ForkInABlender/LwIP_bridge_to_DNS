from __future__ import annotations

import queue
from dataclasses import dataclass
from enum import IntEnum
from typing import Optional


class InterruptCode(IntEnum):
    PACKET_RECEIVED = 1
    PACKET_TRANSMITTED = 2


class DeviceCommand(IntEnum):
    INFO = 1
    START = 2
    STOP = 3
    RESET = 4
    INJECT_PACKET = 20
    READ_PACKET = 21
    SET_IPV4 = 22
    GET_IPV4 = 23
    SET_MTU = 24
    GET_STATS = 25
    POLL_INTERRUPT = 26
    SHUTDOWN = 27


@dataclass
class DeviceConfiguration:
    name: str = "termux-lwip-device"
    version: str = "2.0"
    mtu: int = 1500
    ipv4_address: str = "127.0.0.1"
    ipv4_netmask: str = "255.0.0.0"
    ipv4_gateway: str = "127.0.0.1"
    dns_address: str = "127.0.0.1"
    dns_port: int = 53
    socket_path: str = "~/python-lwip-device.sock"
    state_path: str = "~/python-lwip-device-state.json"


class PythonPacketDevice:
    """TUN-like packet device: packets are raw IPv4/IPv6, no Ethernet header."""

    def __init__(self, configuration: Optional[DeviceConfiguration] = None) -> None:
        self.configuration = configuration or DeviceConfiguration()
        self.rx_packets: queue.Queue[bytes] = queue.Queue()
        self.tx_packets: queue.Queue[bytes] = queue.Queue()
        self.interrupts: queue.Queue[InterruptCode] = queue.Queue()
        self.rx_packet_count = 0
        self.tx_packet_count = 0
        self.rx_byte_count = 0
        self.tx_byte_count = 0
        self.dropped_packet_count = 0
        self.malformed_packet_count = 0
        self.dns_udp_query_count = 0
        self.dns_tcp_query_count = 0
        self.dns_response_count = 0
        self.dns_error_count = 0

    def _raise_interrupt(self, code: InterruptCode) -> None:
        self.interrupts.put(code)

    def inject_packet(self, packet: bytes) -> None:
        if not packet:
            raise ValueError("Empty packet")
        if len(packet) > self.configuration.mtu:
            self.dropped_packet_count += 1
            raise ValueError("Packet exceeds MTU")
        validate_ipv4_packet(packet)
        self.rx_packets.put(packet)
        self.rx_packet_count += 1
        self.rx_byte_count += len(packet)
        self._raise_interrupt(InterruptCode.PACKET_RECEIVED)

    def receive_packet(self, timeout: float = 0.0) -> bytes | None:
        try:
            return self.rx_packets.get(timeout=timeout)
        except queue.Empty:
            return None

    def transmit_packet(self, packet: bytes) -> None:
        if not packet:
            raise ValueError("Empty packet")
        if len(packet) > self.configuration.mtu:
            self.dropped_packet_count += 1
            raise ValueError("Packet exceeds MTU")
        validate_ipv4_packet(packet)
        self.tx_packets.put(packet)
        self.tx_packet_count += 1
        self.tx_byte_count += len(packet)
        self._raise_interrupt(InterruptCode.PACKET_TRANSMITTED)

    def next_transmitted_packet(self, timeout: float = 0.0) -> bytes | None:
        try:
            return self.tx_packets.get(timeout=timeout)
        except queue.Empty:
            return None

    def poll_interrupt(self, timeout: float = 0.0) -> InterruptCode | None:
        try:
            return self.interrupts.get(timeout=timeout)
        except queue.Empty:
            return None

    def get_stats(self) -> dict[str, int]:
        return {
            "rx_packet_count": self.rx_packet_count,
            "tx_packet_count": self.tx_packet_count,
            "rx_byte_count": self.rx_byte_count,
            "tx_byte_count": self.tx_byte_count,
            "dropped_packet_count": self.dropped_packet_count,
            "malformed_packet_count": self.malformed_packet_count,
            "dns_udp_query_count": self.dns_udp_query_count,
            "dns_tcp_query_count": self.dns_tcp_query_count,
            "dns_response_count": self.dns_response_count,
            "dns_error_count": self.dns_error_count,
        }


def validate_ipv4_packet(packet: bytes) -> None:
    if len(packet) < 20:
        raise ValueError("IPv4 packet too short")
    version = packet[0] >> 4
    ihl = packet[0] & 0x0F
    if version != 4:
        raise ValueError("Not IPv4")
    header_length = ihl * 4
    if header_length < 20:
        raise ValueError("Invalid IPv4 header length")
    if len(packet) < header_length:
        raise ValueError("Truncated IPv4 header")
    total_length = int.from_bytes(packet[2:4], "big")
    if total_length > len(packet):
        raise ValueError("Truncated IPv4 packet")
