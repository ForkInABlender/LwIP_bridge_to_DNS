from flask import Flask

app = Flask(__name__)

@app.get("/")
def index():
    return "Public Flask endpoint\n"

app.run(host="127.0.0.1", port=5000)
